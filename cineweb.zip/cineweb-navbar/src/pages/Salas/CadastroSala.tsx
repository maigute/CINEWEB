import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate, Link, useParams } from "react-router-dom";
import api from "../../services/api";
import { salaSchema, type SalaSchema } from "../../schemas/salaSchema";

export default function CadastroSala() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdicao = !!id;

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(salaSchema),
  });

  useEffect(() => {
    if (isEdicao) {
      api.get(`/salas/${id}`)
        .then((response) => reset(response.data))
        .catch((error) => {
          console.error("Erro ao carregar sala:", error);
          alert("Erro ao carregar dados da sala.");
          navigate("/salas");
        });
    }
  }, [id, isEdicao, reset, navigate]);

  const onSubmit = async (data: SalaSchema) => {
    try {
      if (isEdicao) {
        await api.put(`/salas/${id}`, data);
        alert("Sala atualizada com sucesso!");
      } else {
        await api.post("/salas", data);
        alert("Sala cadastrada com sucesso!");
      }
      navigate("/salas");
    } catch (error) {
      console.error("Erro ao salvar sala:", error);
      alert("Erro ao salvar. Verifique o console.");
    }
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>{isEdicao ? "Editar Sala" : "Nova Sala"}</h2>
        <Link to="/salas" className="btn btn-outline-secondary">
          <i className="bi bi-arrow-left"></i> Voltar
        </Link>
      </div>

      <div className="card shadow-sm" style={{ maxWidth: "600px", margin: "0 auto" }}>
        <div className="card-body">
          <form onSubmit={handleSubmit(onSubmit)}>
            
            {/* Número da Sala */}
            <div className="mb-3">
              <label htmlFor="numero" className="form-label">
                <i className="bi bi-door-closed me-2"></i>Número da Sala
              </label>
              <input
                type="number"
                id="numero"
                className={`form-control ${errors.numero ? "is-invalid" : ""}`}
                placeholder="Ex: 1"
                {...register("numero")}
              />
              {errors.numero && (
                <div className="invalid-feedback">{errors.numero.message as string}</div>
              )}
            </div>

            {/* Capacidade */}
            <div className="mb-4">
              <label htmlFor="capacidade" className="form-label">
                <i className="bi bi-people-fill me-2"></i>Capacidade Máxima
              </label>
              <input
                type="number"
                id="capacidade"
                className={`form-control ${errors.capacidade ? "is-invalid" : ""}`}
                placeholder="Ex: 50"
                {...register("capacidade")}
              />
              {errors.capacidade && (
                <div className="invalid-feedback">{errors.capacidade.message as string}</div>
              )}
            </div>

            <div className="d-grid gap-2">
              <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
                {isSubmitting ? "Salvando..." : (
                  <>
                    <i className="bi bi-floppy me-2"></i> Salvar Sala
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}