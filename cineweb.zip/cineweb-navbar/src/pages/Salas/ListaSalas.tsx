import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../../services/api";
import type { Sala } from "../../models/Sala";

export default function ListaSalas() {
  const [salas, setSalas] = useState<Sala[]>([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState("");

  useEffect(() => {
    loadSalas();
  }, []);

  const loadSalas = async () => {
    try {
      setLoading(true);
      const response = await api.get("/salas");
      setSalas(response.data);
    } catch (error) {
      console.error(error);
      setErro("Erro ao carregar salas.");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (window.confirm("Deseja realmente excluir esta sala?")) {
      try {
        await api.delete(`/salas/${id}`);
        setSalas(salas.filter((sala) => sala.id !== id));
      } catch (error) {
        console.error(error);
        alert("Erro ao excluir sala.");
      }
    }
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Gerenciar Salas</h2>
        <Link to="/salas/cadastro" className="btn btn-primary">
          <i className="bi bi-plus-lg me-2"></i> Nova Sala
        </Link>
      </div>

      {loading && <div className="text-center"><div className="spinner-border text-primary"></div></div>}
      {erro && <div className="alert alert-danger">{erro}</div>}

      {!loading && !erro && (
        <div className="card shadow-sm">
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="table table-striped table-hover mb-0">
                <thead className="table-light">
                  <tr>
                    <th># ID</th>
                    <th>Número da Sala</th>
                    <th>Capacidade</th>
                    <th className="text-end">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {salas.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="text-center py-4 text-muted">Nenhuma sala cadastrada.</td>
                    </tr>
                  ) : (
                    salas.map((sala) => (
                      <tr key={sala.id}>
                        <td>{sala.id}</td>
                        <td className="fw-bold">Sala {sala.numero}</td>
                        <td>
                          <i className="bi bi-people me-2"></i>
                          {sala.capacidade} lugares
                        </td>
                        <td className="text-end">
                          <Link to={`/salas/editar/${sala.id}`} className="btn btn-sm btn-outline-primary me-2">
                            <i className="bi bi-pencil"></i>
                          </Link>
                          <button onClick={() => handleDelete(sala.id)} className="btn btn-sm btn-outline-danger">
                            <i className="bi bi-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}