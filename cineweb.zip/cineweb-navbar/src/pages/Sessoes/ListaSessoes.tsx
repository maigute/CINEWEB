import { useEffect, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import api from "../../services/api";
import ModalVenda from "./ModalVenda";

// Interfaces
import type { Sessao } from "../../models/Sessao";
import type { Filme } from "../../models/Filme";
import type { Sala } from "../../models/Sala";
import type { Ingresso } from "../../models/Ingresso"; // Importar Ingresso

export default function ListaSessoes() {
  const [sessoes, setSessoes] = useState<Sessao[]>([]);
  const [filmes, setFilmes] = useState<Filme[]>([]);
  const [salas, setSalas] = useState<Sala[]>([]);
  const [ingressos, setIngressos] = useState<Ingresso[]>([]); // Estado para ingressos
  const [loading, setLoading] = useState(true);
  
  const [sessaoSelecionada, setSessaoSelecionada] = useState<Sessao | null>(null);
  const [showModal, setShowModal] = useState(false);

  // Movi o loadData para fora do useEffect e usei useCallback para poder chamar ele de novo
  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      // Agora buscamos também os ingressos
      const [resSessoes, resFilmes, resSalas, resIngressos] = await Promise.all([
        api.get("/sessoes"),
        api.get("/filmes"),
        api.get("/salas"),
        api.get("/ingressos"),
      ]);
      
      setSessoes(resSessoes.data);
      setFilmes(resFilmes.data);
      setSalas(resSalas.data);
      setIngressos(resIngressos.data);
    } catch (error) {
      console.error(error);
      alert("Erro ao carregar dados.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleDelete = async (id: string | number) => { // Ajuste para aceitar string/number
    if (window.confirm("Tem certeza que deseja cancelar esta sessão?")) {
      try {
        await api.delete(`/sessoes/${id}`);
        setSessoes(sessoes.filter((s) => String(s.id) !== String(id)));
      } catch (error) {
        console.error(error);
        alert("Erro ao excluir a sessão.");
      }
    }
  };

  const handleVenderIngresso = (sessao: Sessao) => {
    setSessaoSelecionada(sessao);
    setShowModal(true);
  };

  // Quando fechar o modal, recarregamos os dados para atualizar o contador de vendas
  const handleCloseModal = () => {
    setShowModal(false);
    loadData(); // Atualiza a contagem de ingressos na tabela
  };

  // --- Helpers de Exibição ---

  const getNomeFilme = (id: string | number) => {
    const filme = filmes.find((f) => String(f.id) === String(id));
    return filme ? filme.titulo : "Filme não encontrado";
  };

  const getSalaInfo = (id: number) => {
    return salas.find((s) => String(s.id) === String(id));
  };

  const formatarData = (dataISO: string) => {
    return new Date(dataISO).toLocaleString("pt-BR", {
      dateStyle: "short",
      timeStyle: "short",
    });
  };

  // NOVO: Calcula quantos ingressos foram vendidos para essa sessão
  const getLotacao = (sessao: Sessao) => {
    const sala = getSalaInfo(sessao.salaId);
    const capacidade = sala ? sala.capacidade : 0;
    
    // Filtra ingressos onde o sessaoId bate com o ID da sessão atual
    // Importante: garantimos a comparação de strings
    const vendidos = ingressos.filter(i => String(i.sessaoId) === String(sessao.id)).length;
    
    const percentual = capacidade > 0 ? (vendidos / capacidade) * 100 : 0;
    
    // Retorna um objeto ou JSX direto
    return {
        texto: `${vendidos} / ${capacidade}`,
        percentual,
        isLotado: vendidos >= capacidade
    };
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Gestão de Sessões</h2>
        <Link to="/sessoes/cadastro" className="btn btn-primary">
          <i className="bi bi-plus-lg me-2"></i> Nova Sessão
        </Link>
      </div>

      {loading && (
        <div className="text-center my-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Carregando...</span>
          </div>
        </div>
      )}

      {!loading && (
        <div className="card shadow-sm">
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="table table-striped table-hover mb-0 align-middle">
                <thead className="table-light">
                  <tr>
                    <th>Data</th>
                    <th>Filme</th>
                    <th>Sala</th>
                    <th style={{width: '150px'}}>Lotação</th> {/* Nova Coluna */}
                    <th className="text-end">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {sessoes.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-4 text-muted">
                        Nenhuma sessão agendada.
                      </td>
                    </tr>
                  ) : (
                    sessoes.map((sessao) => {
                        const lotacao = getLotacao(sessao);
                        const sala = getSalaInfo(sessao.salaId);

                        return (
                          <tr key={sessao.id}>
                            <td>{formatarData(sessao.dataHora)}</td>
                            <td className="fw-bold">{getNomeFilme(sessao.filmeId)}</td>
                            <td>Sala {sala?.numero || "?"}</td>
                            
                            {/* Coluna de Lotação com Barra de Progresso */}
                            <td>
                                <div className="d-flex flex-column">
                                    <small className="fw-bold text-muted mb-1">
                                        {lotacao.texto} <i className="bi bi-people-fill"></i>
                                    </small>
                                    <div className="progress" style={{height: '6px'}}>
                                        <div 
                                            className={`progress-bar ${lotacao.isLotado ? 'bg-danger' : 'bg-success'}`} 
                                            role="progressbar" 
                                            style={{width: `${lotacao.percentual}%`}}
                                        ></div>
                                    </div>
                                </div>
                            </td>

                            <td className="text-end">
                              <button 
                                onClick={() => handleVenderIngresso(sessao)}
                                className="btn btn-sm btn-success me-2"
                                title="Vender Ingresso"
                                disabled={lotacao.isLotado} // Desabilita se lotou
                              >
                                <i className="bi bi-ticket-perforated"></i>
                              </button>
                              
                              <Link 
                                to={`/sessoes/editar/${sessao.id}`} 
                                className="btn btn-sm btn-outline-primary me-2"
                              >
                                <i className="bi bi-pencil"></i>
                              </Link>
                              
                              <button 
                                onClick={() => handleDelete(sessao.id)} 
                                className="btn btn-sm btn-outline-danger"
                              >
                                <i className="bi bi-trash"></i>
                              </button>
                            </td>
                          </tr>
                        );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modal só abre se tiver sessão selecionada */}
      {showModal && sessaoSelecionada && (
        <ModalVenda 
          show={showModal}
          sessao={sessaoSelecionada}
          handleClose={handleCloseModal} // Agora chama a função que recarrega os dados
        />
      )}
    </div>
  );
}