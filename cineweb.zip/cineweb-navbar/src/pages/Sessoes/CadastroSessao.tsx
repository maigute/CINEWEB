import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate, Link, useParams } from "react-router-dom";
import api from "../../services/api";
import { sessaoSchema, type SessaoSchema } from "../../schemas/sessaoSchema";

// Interfaces auxiliares para os selects
import type { Filme } from "../../models/Filme";
import type { Sala } from "../../models/Sala";

export default function CadastroSessao() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdicao = !!id;

  // Estados para armazenar as opções dos selects
  const [filmes, setFilmes] = useState<Filme[]>([]);
  const [salas, setSalas] = useState<Sala[]>([]);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(sessaoSchema),
  });

  // Carregar Filmes e Salas ao montar a tela
  useEffect(() => {
    const loadDadosAuxiliares = async () => {
      try {
        const [resFilmes, resSalas] = await Promise.all([
          api.get("/filmes"),
          api.get("/salas"),
        ]);
        setFilmes(resFilmes.data);
        setSalas(resSalas.data);
      } catch (error) {
        console.error("Erro ao carregar listas:", error);
        alert("Erro ao carregar filmes e salas.");
      }
    };

    loadDadosAuxiliares();
  }, []);

  // Carregar dados da Sessão se for edição
  useEffect(() => {
    if (isEdicao) {
      api.get(`/sessoes/${id}`)
        .then((response) => {
          const sessao = response.data;
          // Ajuste: O input type="datetime-local" precisa do formato YYYY-MM-DDTHH:MM
          // Se sua API retorna ISO completo (com Z ou segundos), talvez precise formatar.
          // O json-server salva como string, então vamos passar direto por enquanto.
          reset(sessao);
        })
        .catch((error) => {
          console.error("Erro ao carregar sessão:", error);
          navigate("/sessoes");
        });
    }
  }, [id, isEdicao, reset, navigate]);

  const onSubmit = async (data: SessaoSchema) => {
    try {
      if (isEdicao) {
        await api.put(`/sessoes/${id}`, data);
        alert("Sessão atualizada!");
      } else {
        await api.post("/sessoes", data);
        alert("Sessão agendada!");
      }
      navigate("/sessoes");
    } catch (error) {
      console.error(error);
      alert("Erro ao salvar sessão.");
    }
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>{isEdicao ? "Editar Sessão" : "Agendar Sessão"}</h2>
        <Link to="/sessoes" className="btn btn-outline-secondary">
          <i className="bi bi-arrow-left"></i> Voltar
        </Link>
      </div>

      <div className="card shadow-sm">
        <div className="card-body">
          <form onSubmit={handleSubmit(onSubmit)} className="row g-3">
            
            {/* Select de Filmes */}
            <div className="col-md-6">
              <label htmlFor="filmeId" className="form-label">Filme</label>
              <select
                id="filmeId"
                className={`form-select ${errors.filmeId ? "is-invalid" : ""}`}
                {...register("filmeId")}
              >
                <option value="">Selecione um filme...</option>
                {filmes.map((filme) => (
                  <option key={filme.id} value={filme.id}>
                    {filme.titulo}
                  </option>
                ))}
              </select>
              {errors.filmeId && <div className="invalid-feedback">{errors.filmeId.message as string}</div>}
            </div>

            {/* Select de Salas */}
            <div className="col-md-3">
              <label htmlFor="salaId" className="form-label">Sala</label>
              <select
                id="salaId"
                className={`form-select ${errors.salaId ? "is-invalid" : ""}`}
                {...register("salaId")}
              >
                <option value="">Selecione...</option>
                {salas.map((sala) => (
                  <option key={sala.id} value={sala.id}>
                    Sala {sala.numero} (Cap: {sala.capacidade})
                  </option>
                ))}
              </select>
              {errors.salaId && <div className="invalid-feedback">{errors.salaId.message as string}</div>}
            </div>

            {/* Data e Hora */}
            <div className="col-md-3">
              <label htmlFor="dataHora" className="form-label">Data e Horário</label>
              <input
                type="datetime-local"
                id="dataHora"
                className={`form-control ${errors.dataHora ? "is-invalid" : ""}`}
                {...register("dataHora")}
              />
              {errors.dataHora && <div className="invalid-feedback">{errors.dataHora.message as string}</div>}
            </div>

            <div className="col-12 mt-4">
              <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
                {isSubmitting ? "Salvando..." : <><i className="bi bi-calendar-check me-2"></i> Agendar Sessão</>}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}