import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import api from "../../services/api";
import { ingressoSchema, type IngressoSchema } from "../../schemas/ingressoSchema";
import { TipoIngressoEnum, MultiplicadorIngresso } from "../../enum/TipoIngressoEnum";
import type { Sessao } from "../../models/Sessao";

interface ModalVendaProps {
  sessao: Sessao | null;
  show: boolean;
  handleClose: () => void;
}

export default function ModalVenda({ sessao, show, handleClose }: ModalVendaProps) {
  const [valorFinal, setValorFinal] = useState(0);
  
  // Sugestão: Pegar isso do objeto sessão futuramente
  const PRECO_BASE = 30.00;

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(ingressoSchema),
    defaultValues: {
      sessaoId: "",
      tipo: TipoIngressoEnum.INTEIRA
    }
  });

  const tipoSelecionado = watch("tipo");

  useEffect(() => {
    if (show && sessao) {
      reset({
        sessaoId: String(sessao.id),
        tipo: TipoIngressoEnum.INTEIRA
      });
      setValorFinal(PRECO_BASE); 
    }
  }, [show, sessao, reset]);

  // Calcula o valor final
  useEffect(() => {
    if (tipoSelecionado) {
      const multiplicador = MultiplicadorIngresso[tipoSelecionado as TipoIngressoEnum] || 1;
      setValorFinal(PRECO_BASE * multiplicador);
    }
  }, [tipoSelecionado]);

  const onSubmit = async (data: IngressoSchema) => {
    console.log("Tentando enviar dados:", data); // DEBUG

    try {
      const payload = {
        ...data,
        valor: valorFinal,
        dataVenda: new Date().toISOString()
      };

      const response = await api.post("/ingressos", payload); //
      console.log("Resposta da API:", response); // DEBUG

      alert(`Venda realizada com sucesso!\nValor: R$ ${valorFinal.toFixed(2)}`);
      handleClose();
    } catch (error) {
      console.error("Erro CRÍTICO na venda:", error);
      alert("Erro ao processar venda. Verifique o console (F12).");
    }
  };

  // Função para capturar erros de validação que impedem o submit
  const onError = (errors: any) => {
    console.log("Erro de Validação do Formulário:", errors);
    if (errors.sessaoId) {
      alert("Erro: ID da sessão inválido.");
    }
  };

  if (!show || !sessao) return null;

  return (
    <div className="modal fade show d-block" style={{ backgroundColor: "rgba(0,0,0,0.5)" }} tabIndex={-1}>
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">
              <i className="bi bi-ticket-perforated-fill me-2"></i>
              Vender Ingresso
            </h5>
            <button type="button" className="btn-close" onClick={handleClose}></button>
          </div>
          
          {/* Adicionado onError no handleSubmit para debug */}
          <form onSubmit={handleSubmit(onSubmit, onError)}>
            <div className="modal-body">
              <p className="mb-1"><strong>Sessão #{sessao.id}</strong></p>
              <p className="text-muted small">Data: {new Date(sessao.dataHora).toLocaleString()}</p>
              
              <hr />

              {/* Input oculto mantido, mas agora o reset garante o valor correto */}
              <input type="hidden" {...register("sessaoId")} />

              <div className="mb-3">
                <label className="form-label">Tipo de Ingresso</label>
                <select 
                  className={`form-select ${errors.tipo ? "is-invalid" : ""}`}
                  {...register("tipo")}
                >
                  {Object.values(TipoIngressoEnum).map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
                {errors.tipo && <div className="invalid-feedback">{errors.tipo.message as string}</div>}
              </div>

              <div className="alert alert-info d-flex justify-content-between align-items-center">
                <span>Valor a Pagar:</span>
                <span className="h4 mb-0 fw-bold">R$ {valorFinal.toFixed(2)}</span>
              </div>
            </div>

            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={handleClose}>
                Cancelar
              </button>
              <button type="submit" className="btn btn-success" disabled={isSubmitting}>
                {isSubmitting ? "Processando..." : (
                  <>
                    <i className="bi bi-currency-dollar me-2"></i> Confirmar Venda
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}