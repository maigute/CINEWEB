import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../../services/api";
import type { Filme } from "../../models/Filme";

export default function ListaFilmes() {
    const [filmes, setFilmes] = useState<Filme[]>([]);
    const [loading, setLoading] = useState(true);
    const [erro, setErro] = useState("");

    // Função para buscar filmes na API
    const loadFilmes = async () => {
        try {
            setLoading(true);
            const response = await api.get("/filmes");
            setFilmes(response.data);
            setErro("");
        } catch (error) {
            console.error("Erro ao carregar filmes:", error);
            setErro("Não foi possível carregar a lista de filmes.");
        } finally {
            setLoading(false);
        }
    };

    // Carrega os dados ao montar o componente
    useEffect(() => {
        loadFilmes();
    }, []);

    // Função de Exclusão [cite: 68]
    const handleDelete = async (id: number) => {
        const confirmacao = window.confirm("Tem certeza que deseja excluir este filme?");

        if (confirmacao) {
            try {
                await api.delete(`/filmes/${id}`);
                // Remove o item da lista localmente para não precisar recarregar a API
                setFilmes(filmes.filter(filme => filme.id !== id));
                alert("Filme removido com sucesso!");
            } catch (error) {
                console.error("Erro ao deletar:", error);
                alert("Erro ao excluir o filme.");
            }
        }
    };

    return (
        <div className="container mt-4">
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h2>Gerenciar Filmes</h2>
                <Link to="/filmes/cadastro" className="btn btn-primary">
                    <i className="bi bi-plus-lg me-2"></i> Novo Filme
                </Link>
            </div>

            {/* Feedback de Carregamento e Erro */}
            {loading && (
                <div className="text-center my-5">
                    <div className="spinner-border text-primary" role="status">
                        <span className="visually-hidden">Carregando...</span>
                    </div>
                </div>
            )}

            {erro && <div className="alert alert-danger">{erro}</div>}

            {/* Tabela de Listagem [cite: 66] */}
            {!loading && !erro && (
                <div className="card shadow-sm">
                    <div className="card-body p-0">
                        <div className="table-responsive">
                            <table className="table table-striped table-hover mb-0">
                                <thead className="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Título</th>
                                        <th>Gênero</th>
                                        <th>Duração</th>
                                        <th>Classificação</th>
                                        <th className="text-end">Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filmes.length === 0 ? (
                                        <tr>
                                            <td colSpan={6} className="text-center py-4 text-muted">
                                                Nenhum filme cadastrado.
                                            </td>
                                        </tr>
                                    ) : (
                                        filmes.map((filme) => (
                                            <tr key={filme.id}>
                                                <td>{filme.id}</td>
                                                <td className="fw-bold">{filme.titulo}</td>
                                                <td>{filme.genero}</td>
                                                <td>{filme.duracao} min</td>
                                                <td>
                                                    <span className="badge bg-secondary">
                                                        {filme.classificacao}
                                                    </span>
                                                </td>
                                                <td className="text-end">
                                                    {/* Botão de Editar */}
                                                    <Link
                                                        to={`/filmes/editar/${filme.id}`}
                                                        className="btn btn-sm btn-outline-primary me-2"
                                                        title="Editar Filme"
                                                    >
                                                        <i className="bi bi-pencil"></i>
                                                    </Link>

                                                    {/* Botão de Exclusão (que já existia) */}
                                                    <button
                                                        onClick={() => handleDelete(filme.id)}
                                                        className="btn btn-sm btn-outline-danger"
                                                        title="Excluir Filme"
                                                    >
                                                        <i className="bi bi-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}