import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate, Link, useParams } from "react-router-dom"; // Adicionado useParams
import api from "../../services/api";
import { filmeSchema, type FilmeSchema } from "../../schemas/filmeSchema";
import { GeneroFilmeEnum } from "../../enum/GeneroFilmeEnum";

export default function CadastroFilme() {
  const navigate = useNavigate();
  const { id } = useParams(); // Pega o ID da URL (se existir)
  const isEdicao = !!id; // Transforma em booleano: true se for edição, false se for novo

  const {
    register,
    handleSubmit,
    reset, // Função para preencher o formulário com dados
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(filmeSchema),
  });

  // Carregar dados do filme se for edição
  useEffect(() => {
    if (isEdicao) {
      api.get(`/filmes/${id}`)
        .then((response) => {
          // O reset preenche automaticamente todos os inputs que tenham o mesmo nome das chaves do objeto
          reset(response.data); 
        })
        .catch((error) => {
          console.error("Erro ao carregar filme:", error);
          alert("Erro ao carregar dados do filme.");
          navigate("/filmes");
        });
    }
  }, [id, isEdicao, reset, navigate]);

  const onSubmit = async (data: FilmeSchema) => {
    try {
      if (isEdicao) {
        // MODO EDIÇÃO: PUT
        await api.put(`/filmes/${id}`, data);
        alert("Filme atualizado com sucesso!");
      } else {
        // MODO CRIAÇÃO: POST
        await api.post("/filmes", data);
        alert("Filme cadastrado com sucesso!");
      }
      navigate("/filmes");
    } catch (error) {
      console.error("Erro ao salvar filme:", error);
      alert("Erro ao salvar o filme.");
    }
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        {/* Título Dinâmico */}
        <h2>{isEdicao ? "Editar Filme" : "Novo Filme"}</h2>
        <Link to="/filmes" className="btn btn-outline-secondary">
          <i className="bi bi-arrow-left"></i> Voltar
        </Link>
      </div>

      <div className="card shadow-sm">
        <div className="card-body">
          <form onSubmit={handleSubmit(onSubmit)} className="row g-3">
            
            {/* ... OS CAMPOS (INPUTS) CONTINUAM IGUAIS AO ANTERIOR ... */}
            {/* Vou repetir apenas o primeiro para exemplo, mantenha o resto igual */}
            
            <div className="col-md-12">
              <label htmlFor="titulo" className="form-label">Título do Filme</label>
              <input
                type="text"
                id="titulo"
                className={`form-control ${errors.titulo ? "is-invalid" : ""}`}
                {...register("titulo")}
              />
              {errors.titulo && <div className="invalid-feedback">{errors.titulo.message as string}</div>}
            </div>

            {/* ... (Mantenha Sinopse, Duração, Classificação, Gênero e Datas iguais) ... */}
             <div className="col-md-12">
              <label htmlFor="sinopse" className="form-label">Sinopse</label>
              <textarea
                id="sinopse"
                className={`form-control ${errors.sinopse ? "is-invalid" : ""}`}
                rows={3}
                placeholder="Breve descrição do filme..."
                {...register("sinopse")}
              ></textarea>
              {errors.sinopse && <div className="invalid-feedback">{errors.sinopse.message as string}</div>}
            </div>

            <div className="col-md-4">
              <label htmlFor="duracao" className="form-label">Duração (minutos)</label>
              <input
                type="number"
                id="duracao"
                className={`form-control ${errors.duracao ? "is-invalid" : ""}`}
                placeholder="Ex: 120"
                {...register("duracao")}
              />
              {errors.duracao && <div className="invalid-feedback">{errors.duracao.message as string}</div>}
            </div>

            <div className="col-md-4">
              <label htmlFor="classificacao" className="form-label">Classificação</label>
              <select
                id="classificacao"
                className={`form-select ${errors.classificacao ? "is-invalid" : ""}`}
                {...register("classificacao")}
              >
                <option value="">Selecione...</option>
                <option value="Livre">Livre</option>
                <option value="10 anos">10 anos</option>
                <option value="12 anos">12 anos</option>
                <option value="14 anos">14 anos</option>
                <option value="16 anos">16 anos</option>
                <option value="18 anos">18 anos</option>
              </select>
              {errors.classificacao && (
                <div className="invalid-feedback">{errors.classificacao.message as string}</div>
              )}
            </div>

            <div className="col-md-4">
              <label htmlFor="genero" className="form-label">Gênero</label>
              <select
                id="genero"
                className={`form-select ${errors.genero ? "is-invalid" : ""}`}
                {...register("genero")}
              >
                <option value="">Selecione...</option>
                {Object.values(GeneroFilmeEnum).map((genero) => (
                  <option key={genero} value={genero}>
                    {genero}
                  </option>
                ))}
              </select>
              {errors.genero && <div className="invalid-feedback">{errors.genero.message as string}</div>}
            </div>

            <div className="col-md-6">
              <label htmlFor="dataInicioExibicao" className="form-label">Início da Exibição</label>
              <input
                type="date"
                id="dataInicioExibicao"
                className={`form-control ${errors.dataInicioExibicao ? "is-invalid" : ""}`}
                {...register("dataInicioExibicao")}
              />
              {errors.dataInicioExibicao && (
                <div className="invalid-feedback">{errors.dataInicioExibicao.message as string}</div>
              )}
            </div>

            <div className="col-md-6">
              <label htmlFor="dataFinalExibicao" className="form-label">Fim da Exibição</label>
              <input
                type="date"
                id="dataFinalExibicao"
                className={`form-control ${errors.dataFinalExibicao ? "is-invalid" : ""}`}
                {...register("dataFinalExibicao")}
              />
              {errors.dataFinalExibicao && (
                <div className="invalid-feedback">{errors.dataFinalExibicao.message as string}</div>
              )}
            </div>

            <div className="col-12 mt-4 d-flex gap-2">
              <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
                    Salvando...
                  </>
                ) : (
                  <>
                    <i className="bi bi-floppy me-2"></i> 
                    {isEdicao ? "Atualizar Filme" : "Salvar Filme"}
                  </>
                )}
              </button>
              <Link to="/filmes" className="btn btn-secondary">
                Cancelar
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}