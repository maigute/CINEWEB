export enum TipoIngressoEnum {
  INTEIRA = 'INTEIRA',
  MEIA = 'MEIA',
  VIP = 'VIP'
}

// Objeto auxiliar para regras de negócio (opcional, mas útil)
export const MultiplicadorIngresso = {
  [TipoIngressoEnum.INTEIRA]: 1.0,
  [TipoIngressoEnum.MEIA]: 0.5,
  [TipoIngressoEnum.VIP]: 1.5,
};