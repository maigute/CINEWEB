export enum GeneroFilmeEnum {
  ACAO = 'Ação',
  COMEDIA = 'Comédia',
  DRAMA = 'Drama',
  TERROR = 'Terror',
  FICCAO = 'Ficção Científica',
  ANIMACAO = 'Animação'
}