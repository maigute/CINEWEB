import type { Filme } from "./Filme";
import type { Sala } from "./Sala";

export interface Sessao {
    id: string; 
    dataHora: string; 
    filmeId: string; 
    salaId: number;
}

export interface SessaoExibicao extends Sessao {
    filme: Filme; 
    sala: Sala;
}