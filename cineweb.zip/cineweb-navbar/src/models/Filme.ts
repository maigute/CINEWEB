import type { GeneroFilmeEnum } from "../enum/GeneroFilmeEnum";

export interface Filme {
    id: number; // O json-server gera isso automaticamente
    titulo: string;
    sinopse: string;
    classificacao: string; // Ex: "Livre", "12 anos", "18 anos"
    duracao: number; // Em minutos, conforme requisito 4.1
    genero: GeneroFilmeEnum;
    dataInicioExibicao: string; // Usaremos string ISO (YYYY-MM-DD) para facilitar com inputs HTML
    dataFinalExibicao: string;
}