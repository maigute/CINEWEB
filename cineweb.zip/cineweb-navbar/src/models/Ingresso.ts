import type { TipoIngressoEnum } from "../enum/TipoIngressoEnum";

export interface Ingresso {
    id: string; 
    sessaoId: string;
    tipo: TipoIngressoEnum;
    valor: number; 
}