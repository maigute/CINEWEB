export interface Sala {
    id: number;
    numero: number;
    capacidade: number;
}