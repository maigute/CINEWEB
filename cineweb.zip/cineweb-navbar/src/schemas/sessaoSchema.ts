import { z } from "zod";

export const sessaoSchema = z.object({
  filmeId: z.coerce
    .number() 
    .min(1, "Selecione um filme"), 
  
  salaId: z.coerce
    .number()
    .min(1, "Selecione uma sala válida"),

  dataHora: z.coerce
    .date()
    .refine((data) => data > new Date(), {
      message: "A data da sessão não pode ser retroativa",
    }),
});

export type SessaoSchema = z.infer<typeof sessaoSchema>;