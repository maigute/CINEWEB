import { z } from "zod";
import { TipoIngressoEnum } from "../enum/TipoIngressoEnum";

export const ingressoSchema = z.object({
  sessaoId: z.string().min(1, "Sessão inválida"),
  
  tipo: z.nativeEnum(TipoIngressoEnum,{ message: "Selecione um tipo de ingresso válido" }),
});

export type IngressoSchema = z.infer<typeof ingressoSchema>;