import { z } from "zod";
import { GeneroFilmeEnum } from "../enum/GeneroFilmeEnum";

export const filmeSchema = z.object({
  titulo: z.string().min(1, "O título é obrigatório"),
  sinopse: z.string().min(10, "A sinopse deve ter no mínimo 10 caracteres"),
  
  duracao: z.coerce
    .number({ message: "Insira um número válido" })
    .gt(0, "A duração deve ser maior que 0"),
    
  classificacao: z.string().min(1, "Selecione a classificação"),
  
  genero: z.nativeEnum(GeneroFilmeEnum),
  
  dataInicioExibicao: z.string().min(1, "Data de início é obrigatória"),
  dataFinalExibicao: z.string().min(1, "Data final é obrigatória"),
});

export type FilmeSchema = z.infer<typeof filmeSchema>;