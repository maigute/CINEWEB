import { z } from "zod";

export const salaSchema = z.object({
  numero: z.coerce
    .number()
    .int("O número da sala deve ser um inteiro")
    .positive("O número da sala deve ser positivo"),
    
  capacidade: z.coerce
    .number()
    .int("A capacidade deve ser um número inteiro")
    .positive("A capacidade deve ser maior que 0"),
});

export type SalaSchema = z.infer<typeof salaSchema>;