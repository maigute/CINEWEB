import { Routes, Route } from "react-router-dom";

// Imports de Filmes
import ListaFilmes from "../pages/Filmes/ListaFilmes";
import CadastroFilme from "../pages/Filmes/CadastroFilme";

// Imports de Salas (NOVOS)
import ListaSalas from "../pages/Salas/ListaSalas";
import CadastroSala from "../pages/Salas/CadastroSala";
import CadastroSessao from "../pages/Sessoes/CadastroSessao";
import ListaSessoes from "../pages/Sessoes/ListaSessoes";

// Placeholder de Sessões (Mantenha por enquanto)
const EmBreve = ({ pagina }: { pagina: string }) => (
    <div className="container text-center mt-5">
        <h3>Módulo de {pagina}</h3>
        <p className="text-muted">Em desenvolvimento...</p>
    </div>
);

const Home = () => (
    <div className="container text-center mt-5">
        <h1>Bem-vindo ao CineWeb</h1>
        <p className="lead">Sistema de Gestão de Cinema</p>
    </div>
);

export default function AppRoutes() {
    return (
        <Routes>
            <Route path="/" element={<Home />} />

            <Route path="/filmes" element={<ListaFilmes />} />
            <Route path="/filmes/cadastro" element={<CadastroFilme />} />
            <Route path="/filmes/editar/:id" element={<CadastroFilme />} />

            <Route path="/salas" element={<ListaSalas />} />
            <Route path="/salas/cadastro" element={<CadastroSala />} />
            <Route path="/salas/editar/:id" element={<CadastroSala />} />

            <Route path="/sessoes" element={<ListaSessoes />} />
            <Route path="/sessoes/cadastro" element={<CadastroSessao />} />
            <Route path="/sessoes/editar/:id" element={<CadastroSessao />} />

            <Route path="*" element={<EmBreve pagina="Página não encontrada (404)" />} />
        </Routes>
    );
}